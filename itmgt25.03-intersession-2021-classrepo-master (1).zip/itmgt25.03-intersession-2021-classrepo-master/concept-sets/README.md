# README

This is a set of concept notebooks that were written to help you get a grasp of Python. You may wish to go through them to help yourself understand Python better.  

The concent in these concept sets may be a little different from what we display on Canvas.